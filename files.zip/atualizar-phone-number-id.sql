-- Atualiza o campo para guardar o Phone Number ID (usado pelo webhook para identificar a empresa)
-- em vez do número de telefone em si

UPDATE empresas
SET whatsapp_numero = '1165121880025489'
WHERE nome_marca = 'ZionPrint';

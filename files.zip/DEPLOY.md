# Como colocar o webhook da ELIORIS AI online (Render.com)

## Passo 1 — Criar conta no Render
1. Acessa https://render.com
2. Cria conta (pode usar login com GitHub, Google, ou email)

## Passo 2 — Subir o código para o GitHub
O Render precisa buscar o código de um repositório GitHub.

1. Cria um novo repositório no GitHub, ex: `eloris-webhook`
2. Sobe os arquivos `index.js` e `package.json` para esse repositório
   (podes fazer isso pelo próprio site do GitHub, "Add file" → "Upload files",
   sem precisar de terminal)

## Passo 3 — Criar o serviço no Render
1. No painel do Render, clica em **"New +"** → **"Web Service"**
2. Conecta a tua conta GitHub e escolhe o repositório `eloris-webhook`
3. Preenche:
   - **Name**: `eloris-webhook`
   - **Region**: Frankfurt (mais perto de Angola/Europa)
   - **Branch**: main
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Instance Type**: Free

## Passo 4 — Configurar as variáveis de ambiente
Ainda na tela de criação (ou depois em "Environment"), adiciona estas variáveis:

| Nome | Valor |
|---|---|
| `VERIFY_TOKEN` | escolhe uma palavra-senha qualquer, ex: `eloris_verify_2026` |
| `WHATSAPP_TOKEN` | o token de acesso que geraste na Meta (o `EAAk...`) |
| `PHONE_NUMBER_ID` | `1165121880025489` |
| `SUPABASE_URL` | `https://uropuzzucbxhyaxhxsky.supabase.co` |
| `SUPABASE_ANON_KEY` | `sb_publishable_Vv1CNcEuCbz4M_Wlz_bBnQ_sDVjQiyy` |
| `ANTHROPIC_API_KEY` | a tua chave `sk-ant-...` |

**Atenção:** o `WHATSAPP_TOKEN` temporário que temos expira em 24h. Antes de ir para produção de verdade, vamos gerar um token permanente (te aviso quando chegarmos nessa parte).

## Passo 5 — Deploy
1. Clica em **"Create Web Service"**
2. Espera o Render instalar e iniciar o serviço (alguns minutos)
3. Quando pronto, ele te dá uma URL tipo: `https://eloris-webhook.onrender.com`

## Passo 6 — Configurar o Webhook na Meta
1. Volta ao painel da Meta (developers.facebook.com → tua app → WhatsApp → Configuration)
2. Em **"Callback URL"**, cola: `https://eloris-webhook.onrender.com/webhook`
3. Em **"Verify token"**, cola o mesmo valor que puseste em `VERIFY_TOKEN` no Render (ex: `eloris_verify_2026`)
4. Clica em **"Verify and save"**

Se tudo estiver certo, a Meta vai confirmar a verificação com sucesso.

## Passo 7 — Subscrever aos eventos de mensagens
Ainda na mesma tela, marca a opção **"messages"** no campo de subscrição do webhook (garante que ele recebe as mensagens dos clientes).

## Passo 8 — Testar
Manda uma mensagem de WhatsApp para o número da ZionPrint (+244 932 873 464) a partir do teu telemóvel pessoal, e vê se a Elioris responde automaticamente!

---

**Nota sobre o plano gratuito do Render:** o serviço "adormece" depois de 15 minutos sem uso, e demora uns 30-60 segundos para "acordar" na primeira mensagem depois disso. Para produção real com clientes, vale considerar o plano pago (a partir de ~$7/mês) para manter sempre ativo.
